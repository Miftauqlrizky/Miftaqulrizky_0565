# SimpleApiPHP
Contoh API PHP Sederhana

- Import db_kampus.sql
- Ubah koneksi.php sesuaikan dengan host,username,password, dan db anda
